const { getActiveWindow } = require('../getActiveWindow');

//const findOpenGuiProcesses = require('./nodeShell').findOpenGuiProcesses

function getGuiProcessMap(){
    let masterMap = new Map();

    const getProcess = async ()=>{
          getActiveWindow((err,activeWindow)=>{
              if(!err){
                console.log("Active Window",activeWindow)
                let obj;
                if(masterMap.has(activeWindow.app)){
                     obj = masterMap.get(activeWindow.app)
                    if(!obj.titles.includes(activeWindow.title)){
                           obj.titles.push(activeWindow.title)
                           masterMap = masterMap.set(activeWindow.app,{...obj})
                           return;
                    }
                }
                masterMap = masterMap.set(activeWindow.app,{app : activeWindow.app, titles : [activeWindow.title]})
              }
          })
          
        
    }

    const interval = setInterval(()=>{
           getProcess();
    },3000)
    setTimeout(()=>{
        clearInterval(interval)
        console.log("Final Applications:::",masterMap)
    },50000)

}

getGuiProcessMap()
